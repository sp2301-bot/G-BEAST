enum attendanceType { IN, OUT, UNDETERMINED }

