import 'package:flutter/material.dart';

const dashBoardColor = Color.fromRGBO(72, 128, 209, 1);
const splashScreenColorBottom = Color.fromRGBO(72, 128, 209, 1);
const splashScreenColorTop= Color.fromRGBO(72, 128, 209, 0.6);
const appbarcolor=Color.fromRGBO(72, 128, 209, 1);
const leaveCardcolor =  Color(0xFF8685E5);